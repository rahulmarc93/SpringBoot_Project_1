package socialmedia_24_7.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialMediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
