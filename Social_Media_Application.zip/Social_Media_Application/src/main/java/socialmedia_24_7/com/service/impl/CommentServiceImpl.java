package socialmedia_24_7.com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import socialmedia_24_7.com.dto.CommentDto;
import socialmedia_24_7.com.repository.CommentRepository;
import socialmedia_24_7.com.service.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Override
    public void commentOnPost(CommentDto commentDto) {
        // Logic to comment on a post
    }

    @Override
    public void deleteComment(Long id) {
        commentRepository.deleteById(id);
    }
}
