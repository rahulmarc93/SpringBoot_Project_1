package socialmedia_24_7.com.service;

import socialmedia_24_7.com.dto.UserDto;
import socialmedia_24_7.com.dto.UserRegistrationDto;
import org.springframework.validation.BindingResult;

import java.util.Map;

public interface UserService {
    void registerUser(UserRegistrationDto userDto);
    UserDto getUserProfile(Long userId);
    Map<String, String> collectErrors(BindingResult bindingResult);
    boolean isUsernameTaken(String username);
    boolean isEmailTaken(String email);
    boolean authenticateUser(String username, String password);
}
