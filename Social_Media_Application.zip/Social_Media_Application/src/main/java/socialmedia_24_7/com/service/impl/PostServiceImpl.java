package socialmedia_24_7.com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import socialmedia_24_7.com.dto.PostDto;
import socialmedia_24_7.com.entity.Post;
import socialmedia_24_7.com.entity.User;
import socialmedia_24_7.com.exception.ResourceNotFoundException;
import socialmedia_24_7.com.repository.PostRepository;
import socialmedia_24_7.com.repository.UserRepository;
import socialmedia_24_7.com.service.PostService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void createPost(PostDto postDto, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + userId));
        Post post = new Post();
        post.setContent(postDto.getContent());
        post.setCreatedAt(LocalDateTime.now());
        post.setUser(user);
        postRepository.save(post);
    }

    @Override
    public void deletePost(Long postId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found with ID: " + postId));
        postRepository.delete(post);
    }

    @Override
    public void updatePost(Long postId, PostDto postDto) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found with ID: " + postId));
        post.setContent(postDto.getContent());
        postRepository.save(post);
    }

    @Override
    public List<PostDto> getAllPosts(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + userId));
        return user.getPosts().stream()
                .map(post -> new PostDto(post.getId(), post.getContent(), post.getCreatedAt()))
                .collect(Collectors.toList());
    }
}
