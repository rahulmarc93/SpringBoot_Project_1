package socialmedia_24_7.com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import socialmedia_24_7.com.dto.LikeDto;
import socialmedia_24_7.com.entity.Like;
import socialmedia_24_7.com.entity.Post;
import socialmedia_24_7.com.entity.User;
import socialmedia_24_7.com.exception.ResourceNotFoundException;
import socialmedia_24_7.com.repository.LikeRepository;
import socialmedia_24_7.com.repository.PostRepository;
import socialmedia_24_7.com.repository.UserRepository;
import socialmedia_24_7.com.service.LikeService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LikeServiceImpl implements LikeService {

    @Autowired
    private LikeRepository likeRepository;

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void likePost(LikeDto likeDto) {
        User user = userRepository.findById(likeDto.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + likeDto.getUserId()));

        Post post = postRepository.findById(likeDto.getPostId())
                .orElseThrow(() -> new ResourceNotFoundException("Post not found with ID: " + likeDto.getPostId()));

        // Check if the user already liked the post
        if (likeRepository.findByPostIdAndUserId(likeDto.getPostId(), likeDto.getUserId()).isPresent()) {
            throw new RuntimeException("Post is already liked by the user");
        }

        Like like = new Like();
        like.setPost(post);
        like.setUser(user);
        likeRepository.save(like);
    }

    @Override
    public void unlikePost(LikeDto likeDto) {
        Like like = likeRepository.findByPostIdAndUserId(likeDto.getPostId(), likeDto.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Like not found for post and user"));

        likeRepository.delete(like);
    }

    @Override
    public List<LikeDto> getLikesForPost(Long postId) {
        List<Like> likes = likeRepository.findByPostId(postId);

        return likes.stream().map(like -> new LikeDto(like.getPost().getId(), like.getUser().getId()))
                .collect(Collectors.toList());
    }
}
