package socialmedia_24_7.com.service;

import socialmedia_24_7.com.dto.LikeDto;

import java.util.List;

public interface LikeService {
    void likePost(LikeDto likeDto);
    void unlikePost(LikeDto likeDto);
    List<LikeDto> getLikesForPost(Long postId);
}
