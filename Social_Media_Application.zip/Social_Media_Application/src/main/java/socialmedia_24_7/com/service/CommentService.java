package socialmedia_24_7.com.service;

import socialmedia_24_7.com.dto.CommentDto;

public interface CommentService {
    void commentOnPost(CommentDto commentDto);
    void deleteComment(Long id);
}
