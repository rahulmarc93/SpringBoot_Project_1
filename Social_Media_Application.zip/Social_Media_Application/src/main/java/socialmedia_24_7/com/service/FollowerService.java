package socialmedia_24_7.com.service;

import socialmedia_24_7.com.dto.FollowerDto;

import java.util.List;

public interface FollowerService {
    void followUser(Long followerId, Long followeeId); // For following a user
    void unfollowUser(Long followerId, Long followeeId); // Change this to Long, Long
    List<FollowerDto> getFollowers(Long userId); // For getting a list of followers
    List<FollowerDto> getFollowing(Long userId); // For getting a list of following
}
