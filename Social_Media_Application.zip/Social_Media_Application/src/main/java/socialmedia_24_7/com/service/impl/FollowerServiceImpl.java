package socialmedia_24_7.com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import socialmedia_24_7.com.dto.FollowerDto;
import socialmedia_24_7.com.entity.Follower;
import socialmedia_24_7.com.entity.User;
import socialmedia_24_7.com.exception.ResourceNotFoundException;
import socialmedia_24_7.com.repository.FollowerRepository;
import socialmedia_24_7.com.repository.UserRepository;
import socialmedia_24_7.com.service.FollowerService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FollowerServiceImpl implements FollowerService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FollowerRepository followerRepository;

    @Override
    public void followUser(Long followerId, Long followeeId) {
        // Retrieve follower and followee from the database
        User follower = userRepository.findById(followerId)
                .orElseThrow(() -> new ResourceNotFoundException("Follower not found"));

        User followee = userRepository.findById(followeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Followee not found"));

        // Check if the follower is already following the followee
        if (followerRepository.existsByFollowerAndFollowee(follower, followee)) {
            throw new RuntimeException("Already following this user");
        }

        // Create and save the new follower-followee relationship
        Follower newFollower = new Follower();
        newFollower.setFollower(follower);
        newFollower.setFollowee(followee);
        followerRepository.save(newFollower);
    }

    @Override
    public void unfollowUser(Long followerId, Long followeeId) {
        // Retrieve follower and followee from the database
        User follower = userRepository.findById(followerId)
                .orElseThrow(() -> new ResourceNotFoundException("Follower not found"));

        User followee = userRepository.findById(followeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Followee not found"));

        // Find the follower-followee relationship
        Follower existingFollower = followerRepository.findByFollowerAndFollowee(follower, followee)
                .orElseThrow(() -> new ResourceNotFoundException("Follower relationship not found"));

        // Delete the existing follower-followee relationship
        followerRepository.delete(existingFollower);
    }

    @Override
    public List<FollowerDto> getFollowers(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return followerRepository.findByFollowee(user).stream()
                .map(follower -> new FollowerDto(follower.getFollower().getId(),
                                                follower.getFollower().getUsername(),
                                                follower.getFollowee().getId()))  // pass followeeId here
                .collect(Collectors.toList());
    }

    @Override
    public List<FollowerDto> getFollowing(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return followerRepository.findByFollower(user).stream()
                .map(followee -> new FollowerDto(followee.getFollowee().getId(),
                                                 followee.getFollowee().getUsername(),
                                                 followee.getFollower().getId()))  // pass followeeId here
                .collect(Collectors.toList());
    }
}
