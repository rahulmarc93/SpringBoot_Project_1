package socialmedia_24_7.com.service;

import socialmedia_24_7.com.dto.PostDto;

import java.util.List;

public interface PostService {
    void createPost(PostDto postDto, Long userId); // Already exists
    void deletePost(Long postId); // Define this
    void updatePost(Long postId, PostDto postDto); // Define this
    List<PostDto> getAllPosts(Long userId); // Already exists
}
