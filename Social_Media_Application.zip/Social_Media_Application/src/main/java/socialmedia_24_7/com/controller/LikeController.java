package socialmedia_24_7.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import socialmedia_24_7.com.dto.LikeDto;
import socialmedia_24_7.com.service.LikeService;

@RestController
@RequestMapping("/api/likes")
public class LikeController {

    @Autowired
    private LikeService likeService;

    @PostMapping("/like")
    public void likePost(@RequestBody LikeDto likeDto) {
        likeService.likePost(likeDto);
    }

    @DeleteMapping("/unlike")
    public void unlikePost(@RequestBody LikeDto likeDto) {
        likeService.unlikePost(likeDto);
    }
}
