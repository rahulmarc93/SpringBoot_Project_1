package socialmedia_24_7.com.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import socialmedia_24_7.com.dto.UserRegistrationDto;
import socialmedia_24_7.com.response.AuthResponse;
import socialmedia_24_7.com.service.UserService;
import socialmedia_24_7.com.config.JwtConfig;

@RestController
@RequestMapping("/api/auth") // Base URL for authentication-related actions
public class AuthController {

    @Autowired
    private JwtConfig jwtConfig;

    @Autowired
    private UserService userService;

    @PostMapping("/register") // Endpoint for general registration
    public String register(@RequestBody UserRegistrationDto userDto) {
        userService.registerUser(userDto);
        return "User registered successfully!";
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody Map<String, String> loginRequest) {
        String username = loginRequest.get("username");
        String password = loginRequest.get("password");

        if (userService.authenticateUser(username, password)) {
            String token = jwtConfig.generateToken(username);
            return new AuthResponse(token);
        } else {
            throw new RuntimeException("Invalid credentials");
        }
    }

}
