package socialmedia_24_7.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import socialmedia_24_7.com.dto.CommentDto;
import socialmedia_24_7.com.service.CommentService;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/comment")
    public void commentOnPost(@RequestBody CommentDto commentDto) {
        commentService.commentOnPost(commentDto);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteComment(@PathVariable Long id) {
        commentService.deleteComment(id);
    }
}
