package socialmedia_24_7.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import socialmedia_24_7.com.dto.UserRegistrationDto;
import socialmedia_24_7.com.response.AuthResponse;
import socialmedia_24_7.com.service.UserService;
import socialmedia_24_7.com.config.JwtConfig;

@RestController
@RequestMapping("/api/user") // Separate base URL for UserController
public class UserController {

    @Autowired
    private JwtConfig jwtConfig;

    @Autowired
    private UserService userService;

    @PostMapping("/register") // Endpoint for user registration
    public void register(@RequestBody UserRegistrationDto userDto) {
        userService.registerUser(userDto);
    }

    @PostMapping("/login") // Endpoint for user login
    public AuthResponse login(@RequestParam String username, @RequestParam String password) {
        // Assuming user validation logic is implemented in UserService
        if (userService.authenticateUser(username, password)) {
            String token = jwtConfig.generateToken(username);
            return new AuthResponse(token);
        } else {
            throw new RuntimeException("Invalid credentials");
        }
    }
}
