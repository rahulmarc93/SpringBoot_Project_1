package socialmedia_24_7.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import socialmedia_24_7.com.dto.FollowerDto;
import socialmedia_24_7.com.service.FollowerService;

@RestController
@RequestMapping("/api/followers")
public class FollowerController {

    @Autowired
    private FollowerService followerService;

    // Follow user
    @PostMapping("/follow")
    public void followUser(@RequestBody FollowerDto followerDto) {
        followerService.followUser(followerDto.getId(), followerDto.getFolloweeId());
    }

    // Unfollow user
    @DeleteMapping("/unfollow")
    public void unfollowUser(@RequestBody FollowerDto followerDto) {
        followerService.unfollowUser(followerDto.getId(), followerDto.getFolloweeId());
    }
}
