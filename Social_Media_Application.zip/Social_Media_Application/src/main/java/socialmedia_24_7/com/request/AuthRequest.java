package socialmedia_24_7.com.request;

public class AuthRequest {

}
