package socialmedia_24_7.com.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  // Generates constructor with all fields as parameters
@NoArgsConstructor   // Generates no-arguments constructor
@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Unique identifier for the comment
    private String text;  // Content of the comment

    @ManyToOne
    @JoinColumn(name = "post_id", nullable = false)  // Foreign key to Post
    private Post post;  // Many-to-one relationship with Post
    private Long userId;  // Directly store the user ID
}
