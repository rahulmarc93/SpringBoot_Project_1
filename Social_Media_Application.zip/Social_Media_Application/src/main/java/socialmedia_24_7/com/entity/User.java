package socialmedia_24_7.com.entity;

import java.time.LocalDateTime;
import java.util.List;
import org.hibernate.annotations.CreationTimestamp;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  // Generates constructor with all fields as parameters
@NoArgsConstructor   // Generates no-arguments constructor
@Entity
@Table(name = "users")
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Unique identifier for the user
    
    @NotBlank(message = "Username cannot be blank")
    private String username; // Username for the user

    @NotBlank(message = "Password cannot be blank")
    private String password; // Password for the user

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email cannot be blank")
    private String email; // Email for the user

    @CreationTimestamp
    private LocalDateTime createdAt;  // Timestamp for when the user was created

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Post> posts;  // One-to-many relationship with posts, with cascading behavior

    @OneToMany(mappedBy = "follower", cascade = CascadeType.ALL)
    private List<Follower> followers;
}