package socialmedia_24_7.com.entity;

import java.time.LocalDateTime;
import java.util.List;
import org.hibernate.annotations.CreationTimestamp;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  // Generates constructor with all fields as parameters
@NoArgsConstructor   // Generates no-arguments constructor
@Entity
@Table(name = "posts")
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Unique identifier for the post

    private String content;  // Content of the post

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)  // Foreign key referencing the user
    private User user;  // Many-to-one relationship with the User entity

    @CreationTimestamp
    private LocalDateTime createdAt;  // Timestamp when the post was created

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments;  // One-to-many relationship with comments

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Like> likes;  // One-to-many relationship with likes

}
