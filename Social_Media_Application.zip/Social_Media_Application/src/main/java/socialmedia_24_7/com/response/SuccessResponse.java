package socialmedia_24_7.com.response;

import org.springframework.http.HttpStatus;
import lombok.Data;

@Data
public class SuccessResponse<T> { 
    // 'T' is a generic type that will allow us to pass different types of data
    private HttpStatus status;  // HTTP status (e.g., OK, CREATED, etc.)
    private String message;     // A message providing additional context (e.g., "User registered successfully")
    private T data;             // The actual response data, can be of any type (String, UserDto, List<PostDto>, etc.)

    // Constructor to initialize all fields
    public SuccessResponse(HttpStatus status, String message, T data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }
}
