package socialmedia_24_7.com.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import jakarta.validation.constraints.NotBlank;

@Data
@AllArgsConstructor  // Generates a constructor with all fields as parameters
@NoArgsConstructor   // Generates a no-args constructor
public class PostDto {
    private Long id;
    @NotBlank(message = "Content cannot be blank.")
    private String content;
    private LocalDateTime createdAt;
}