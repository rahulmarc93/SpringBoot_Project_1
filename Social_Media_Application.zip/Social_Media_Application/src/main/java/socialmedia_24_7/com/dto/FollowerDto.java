package socialmedia_24_7.com.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  // Constructor with all fields
@NoArgsConstructor   // Default no-args constructor
public class FollowerDto {
    private Long id;        // Follower's ID
    private String username; // Follower's username
    private Long followeeId; // Followee's ID

    /*/ Constructor to allow instantiation with id, username, and followeeId
    public FollowerDto(Long id, String username, Long followeeId) {
        this.id = id;
        this.username = username;
        this.followeeId = followeeId;
    }

    // Getter for followeeId
    public Long getFolloweeId() {
        return followeeId;
    }

    // Setter for followeeId
    public void setFolloweeId(Long followeeId) {
        this.followeeId = followeeId;
    }*/
}
