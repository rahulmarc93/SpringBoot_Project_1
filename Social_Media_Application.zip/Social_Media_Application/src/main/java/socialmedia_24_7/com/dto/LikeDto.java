package socialmedia_24_7.com.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  // Generates constructor with all fields as parameters
@NoArgsConstructor   // Generates no-arguments constructor
public class LikeDto {

    private Long postId;
    private Long userId;
}
