package socialmedia_24_7.com.dto;

import lombok.Data;

@Data
public class CommentDto {
    private Long userId;
    private Long postId;
    private String comment;
}
