package socialmedia_24_7.com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import socialmedia_24_7.com.entity.Follower;
import socialmedia_24_7.com.entity.User;

import java.util.Optional;
import java.util.List;

public interface FollowerRepository extends JpaRepository<Follower, Long> {
    // Check if a follower-followee relationship exists
    boolean existsByFollowerAndFollowee(User follower, User followee);

    // Find follower-followee relationship
    Optional<Follower> findByFollowerAndFollowee(User follower, User followee);

    // Get all followers of a user (those who follow the given user)
    List<Follower> findByFollowee(User followee);

    // Get all users that a given user is following
    List<Follower> findByFollower(User follower);
}
